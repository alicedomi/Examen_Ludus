package com.example.alice.examen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import de.demo.login.Login;


public class MainActivity extends AppCompatActivity
{
    private TextView tv;
    public static final int RESULT_ActivityMain = 1;

    public void onCreate(Bundle icicle)
    {
        super.onCreate(icicle);

        //Appel de la page de Login
        startActivityForResult(new Intent(MainActivity.this, Login.class), RESULT_ActivityMain);

        tv = new TextView(this);
        setContentView(tv);
    }

    private void startup(Intent i)
    {
        // Récupère l'identifiant
        int user = i.getIntExtra("userid",-1);

        //Affiche les identifiants de l'utilisateur
        tv.setText("UserID: "+String.valueOf(user)+" logged in");
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == RESULT_ActivityMain && resultCode == RESULT_CANCELED)
            finish();
        else
            startup(data);
    }
}